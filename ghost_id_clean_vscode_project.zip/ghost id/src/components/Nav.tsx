import { Link, useNavigate, useRouter } from "@tanstack/react-router";
import { Activity, LogOut } from "lucide-react";
import { useEffect, useState } from "react";
import { session, type Session } from "@/lib/store";
import { Button } from "@/components/ui/button";

export function Nav() {
  const [s, setS] = useState<Session>(null);
  const navigate = useNavigate();
  const router = useRouter();

  useEffect(() => {
    setS(session.get());
  }, [router.state.location.pathname]);

  const logout = () => {
    session.clear();
    setS(null);
    navigate({ to: "/" });
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/60 bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2 font-semibold tracking-tight">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-primary text-primary-foreground">
            <Activity className="h-4 w-4" />
          </span>
          <span className="text-lg">MediQR</span>
        </Link>
        <nav className="flex items-center gap-2 text-sm">
          {!s && (
            <>
              <Link to="/patient/login" className="px-3 py-2 text-muted-foreground hover:text-foreground">
                Patient
              </Link>
              <Link to="/doctor/login" className="px-3 py-2 text-muted-foreground hover:text-foreground">
                Doctor
              </Link>
              <Link to="/admin" className="px-3 py-2 text-muted-foreground hover:text-foreground">
                Admin
              </Link>
            </>
          )}
          {s?.role === "patient" && (
            <Link to="/patient/profile" className="px-3 py-2 text-muted-foreground hover:text-foreground">
              My Profile
            </Link>
          )}
          {s?.role === "doctor" && (
            <Link to="/doctor/profile" className="px-3 py-2 text-muted-foreground hover:text-foreground">
              My Profile
            </Link>
          )}
          {s?.role === "admin" && (
            <Link to="/admin" className="px-3 py-2 text-muted-foreground hover:text-foreground">
              Dashboard
            </Link>
          )}
          {s && (
            <Button variant="ghost" size="sm" onClick={logout}>
              <LogOut className="mr-1 h-4 w-4" /> Logout
            </Button>
          )}
        </nav>
      </div>
    </header>
  );
}