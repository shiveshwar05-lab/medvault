// Placeholder storage layer — replace with real DB calls (Lovable Cloud / Supabase) later.
// All data is currently persisted to localStorage so the prototype is functional end-to-end.

export type Patient = {
  id: string;
  email: string;
  password: string; // placeholder only — never store plaintext in production
  fullName: string;
  dob: string;
  gender: string;
  bloodGroup: string;
  phone: string;
  address: string;
  emergencyContact: string;
  allergies: string;
  chronicConditions: string;
  pastSurgeries: string;
  pastTreatments: string;
  accidents: string;
  medications: string;
  familyHistory: string;
  reports: string; // free text / urls placeholder
  notes: string;
  createdAt: string;
};

export type Doctor = {
  id: string;
  email: string;
  password: string;
  fullName: string;
  specialization: string;
  degrees: string;
  licenseNumber: string;
  hospital: string;
  phone: string;
  yearsExperience: string;
  bio: string;
  status: "pending" | "approved" | "rejected";
  createdAt: string;
};

const KEYS = {
  patients: "mediqr.patients",
  doctors: "mediqr.doctors",
  session: "mediqr.session",
} as const;

function read<T>(k: string): T[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(k) || "[]");
  } catch {
    return [];
  }
}
function write<T>(k: string, v: T[]) {
  localStorage.setItem(k, JSON.stringify(v));
}

export const patientsStore = {
  list: () => read<Patient>(KEYS.patients),
  get: (id: string) => read<Patient>(KEYS.patients).find((p) => p.id === id),
  upsert: (p: Patient) => {
    const all = read<Patient>(KEYS.patients).filter((x) => x.id !== p.id);
    all.push(p);
    write(KEYS.patients, all);
  },
  findByEmail: (email: string) =>
    read<Patient>(KEYS.patients).find((p) => p.email.toLowerCase() === email.toLowerCase()),
};

export const doctorsStore = {
  list: () => read<Doctor>(KEYS.doctors),
  get: (id: string) => read<Doctor>(KEYS.doctors).find((d) => d.id === id),
  upsert: (d: Doctor) => {
    const all = read<Doctor>(KEYS.doctors).filter((x) => x.id !== d.id);
    all.push(d);
    write(KEYS.doctors, all);
  },
  findByEmail: (email: string) =>
    read<Doctor>(KEYS.doctors).find((d) => d.email.toLowerCase() === email.toLowerCase()),
};

export type Session =
  | { role: "patient"; id: string }
  | { role: "doctor"; id: string }
  | { role: "admin" }
  | null;

export const session = {
  get(): Session {
    if (typeof window === "undefined") return null;
    try {
      return JSON.parse(localStorage.getItem(KEYS.session) || "null");
    } catch {
      return null;
    }
  },
  set(s: Session) {
    if (s) localStorage.setItem(KEYS.session, JSON.stringify(s));
    else localStorage.removeItem(KEYS.session);
  },
  clear() {
    localStorage.removeItem(KEYS.session);
  },
};

export function newId() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}