import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Nav } from "@/components/Nav";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { patientsStore, session, newId, type Patient } from "@/lib/store";

export const Route = createFileRoute("/patient/register")({
  component: PatientRegister,
});

function PatientRegister() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (patientsStore.findByEmail(email)) {
      toast.error("An account with that email already exists.");
      return;
    }
    const p: Patient = {
      id: newId(),
      email, password, fullName,
      dob: "", gender: "", bloodGroup: "", phone: "", address: "",
      emergencyContact: "", allergies: "", chronicConditions: "",
      pastSurgeries: "", pastTreatments: "", accidents: "",
      medications: "", familyHistory: "", reports: "", notes: "",
      createdAt: new Date().toISOString(),
    };
    patientsStore.upsert(p);
    session.set({ role: "patient", id: p.id });
    toast.success("Account created. Complete your medical profile.");
    navigate({ to: "/patient/profile" });
  };

  return (
    <div className="min-h-screen bg-background">
      <Nav />
      <div className="mx-auto max-w-md px-4 py-16">
        <h1 className="text-3xl font-semibold tracking-tight">Create your patient account</h1>
        <p className="mt-2 text-sm text-muted-foreground">It only takes a minute. You can fill in your medical history right after.</p>
        <form onSubmit={onSubmit} className="mt-8 space-y-4 rounded-2xl border border-border bg-card p-6">
          <div className="space-y-2">
            <Label>Full name</Label>
            <Input required value={fullName} onChange={(e) => setFullName(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Email</Label>
            <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Password</Label>
            <Input type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <Button type="submit" className="w-full">Create account</Button>
          <p className="text-center text-xs text-muted-foreground">
            Already registered? <Link to="/patient/login" className="text-primary underline">Sign in</Link>
          </p>
        </form>
      </div>
    </div>
  );
}