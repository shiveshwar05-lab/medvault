import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Nav } from "@/components/Nav";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { patientsStore, session } from "@/lib/store";

export const Route = createFileRoute("/patient/login")({
  component: PatientLogin,
});

function PatientLogin() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const p = patientsStore.findByEmail(email);
    if (!p || p.password !== password) {
      toast.error("Invalid email or password.");
      return;
    }
    session.set({ role: "patient", id: p.id });
    navigate({ to: "/patient/profile" });
  };

  return (
    <div className="min-h-screen bg-background">
      <Nav />
      <div className="mx-auto max-w-md px-4 py-16">
        <h1 className="text-3xl font-semibold tracking-tight">Patient sign in</h1>
        <form onSubmit={onSubmit} className="mt-8 space-y-4 rounded-2xl border border-border bg-card p-6">
          <div className="space-y-2"><Label>Email</Label><Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></div>
          <div className="space-y-2"><Label>Password</Label><Input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} /></div>
          <Button type="submit" className="w-full">Sign in</Button>
          <p className="text-center text-xs text-muted-foreground">
            No account? <Link to="/patient/register" className="text-primary underline">Register</Link>
          </p>
        </form>
      </div>
    </div>
  );
}