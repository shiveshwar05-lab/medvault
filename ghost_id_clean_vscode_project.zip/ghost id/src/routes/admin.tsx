import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Check, X, Lock } from "lucide-react";
import { Nav } from "@/components/Nav";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { doctorsStore, session, type Doctor } from "@/lib/store";

// Placeholder credentials — replace with real backend auth later.
const ADMIN_EMAIL = "admin@mediqr.local";
const ADMIN_PASSWORD = "admin123";

export const Route = createFileRoute("/admin")({
  component: Admin,
});

function Admin() {
  const [authed, setAuthed] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [doctors, setDoctors] = useState<Doctor[]>([]);

  useEffect(() => {
    const s = session.get();
    if (s?.role === "admin") setAuthed(true);
  }, []);

  useEffect(() => {
    if (authed) setDoctors(doctorsStore.list());
  }, [authed]);

  const login = (e: React.FormEvent) => {
    e.preventDefault();
    if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
      session.set({ role: "admin" });
      setAuthed(true);
    } else {
      toast.error("Invalid admin credentials.");
    }
  };

  const setStatus = (id: string, status: Doctor["status"]) => {
    const d = doctorsStore.get(id);
    if (!d) return;
    doctorsStore.upsert({ ...d, status });
    setDoctors(doctorsStore.list());
    toast.success(`Doctor ${status}.`);
  };

  if (!authed) {
    return (
      <div className="min-h-screen bg-background">
        <Nav />
        <div className="mx-auto max-w-md px-4 py-16">
          <div className="rounded-2xl border border-border bg-card p-6">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Lock className="h-4 w-4" /> Backend support team access
            </div>
            <h1 className="mt-3 text-2xl font-semibold tracking-tight">Admin sign in</h1>
            <form onSubmit={login} className="mt-6 space-y-4">
              <div className="space-y-2"><Label>Email</Label><Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder={ADMIN_EMAIL} /></div>
              <div className="space-y-2"><Label>Password</Label><Input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} /></div>
              <Button type="submit" className="w-full">Sign in</Button>
              <p className="text-center text-xs text-muted-foreground">
                Placeholder credentials — replace before launch. Default: <code>{ADMIN_EMAIL}</code> / <code>{ADMIN_PASSWORD}</code>
              </p>
            </form>
          </div>
        </div>
      </div>
    );
  }

  const pending = doctors.filter((d) => d.status === "pending");
  const others = doctors.filter((d) => d.status !== "pending");

  return (
    <div className="min-h-screen bg-background">
      <Nav />
      <div className="mx-auto max-w-5xl px-4 py-12">
        <h1 className="text-3xl font-semibold tracking-tight">Doctor verification queue</h1>
        <p className="mt-1 text-sm text-muted-foreground">Review submitted credentials and approve or reject doctor profiles.</p>

        <h2 className="mt-10 text-lg font-medium">Pending ({pending.length})</h2>
        <div className="mt-4 space-y-3">
          {pending.length === 0 && <p className="text-sm text-muted-foreground">No pending requests.</p>}
          {pending.map((d) => (
            <DoctorRow key={d.id} d={d} onApprove={() => setStatus(d.id, "approved")} onReject={() => setStatus(d.id, "rejected")} />
          ))}
        </div>

        <h2 className="mt-10 text-lg font-medium">Reviewed</h2>
        <div className="mt-4 space-y-3">
          {others.length === 0 && <p className="text-sm text-muted-foreground">None yet.</p>}
          {others.map((d) => (
            <DoctorRow key={d.id} d={d} onApprove={() => setStatus(d.id, "approved")} onReject={() => setStatus(d.id, "rejected")} />
          ))}
        </div>
      </div>
    </div>
  );
}

function DoctorRow({ d, onApprove, onReject }: { d: Doctor; onApprove: () => void; onReject: () => void }) {
  return (
    <div className="flex flex-wrap items-start justify-between gap-4 rounded-xl border border-border bg-card p-5">
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <h3 className="font-medium">Dr. {d.fullName}</h3>
          <span className={`rounded-full px-2 py-0.5 text-xs ${
            d.status === "approved" ? "bg-primary/10 text-primary" :
            d.status === "rejected" ? "bg-destructive/10 text-destructive" :
            "bg-amber-500/10 text-amber-600"
          }`}>{d.status}</span>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">{d.specialization} · {d.degrees} · License {d.licenseNumber}</p>
        <p className="text-xs text-muted-foreground">{d.email} · {d.phone || "no phone"} · {d.hospital || "no hospital"}</p>
        {d.bio && <p className="mt-2 text-sm">{d.bio}</p>}
      </div>
      <div className="flex gap-2">
        <Button size="sm" variant="outline" onClick={onReject}><X className="mr-1 h-4 w-4" /> Reject</Button>
        <Button size="sm" onClick={onApprove}><Check className="mr-1 h-4 w-4" /> Approve</Button>
      </div>
    </div>
  );
}