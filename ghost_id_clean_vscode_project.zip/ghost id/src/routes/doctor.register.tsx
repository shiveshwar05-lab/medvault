import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Nav } from "@/components/Nav";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { doctorsStore, session, newId, type Doctor } from "@/lib/store";

export const Route = createFileRoute("/doctor/register")({
  component: DoctorRegister,
});

function DoctorRegister() {
  const navigate = useNavigate();
  const [f, setF] = useState({
    email: "", password: "", fullName: "", specialization: "",
    degrees: "", licenseNumber: "", hospital: "", phone: "",
    yearsExperience: "", bio: "",
  });
  const set = (k: keyof typeof f, v: string) => setF((p) => ({ ...p, [k]: v }));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (doctorsStore.findByEmail(f.email)) {
      toast.error("An account with that email already exists.");
      return;
    }
    const d: Doctor = {
      id: newId(),
      ...f,
      status: "pending",
      createdAt: new Date().toISOString(),
    };
    doctorsStore.upsert(d);
    session.set({ role: "doctor", id: d.id });
    toast.success("Submitted! Our team will verify your credentials soon.");
    navigate({ to: "/doctor/profile" });
  };

  return (
    <div className="min-h-screen bg-background">
      <Nav />
      <div className="mx-auto max-w-2xl px-4 py-12">
        <h1 className="text-3xl font-semibold tracking-tight">Doctor registration</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Fill in your credentials. Profiles are reviewed by the backend support team before approval.
        </p>
        <form onSubmit={submit} className="mt-8 grid gap-4 rounded-2xl border border-border bg-card p-6 md:grid-cols-2">
          <Field label="Full name"><Input required value={f.fullName} onChange={(e) => set("fullName", e.target.value)} /></Field>
          <Field label="Email"><Input type="email" required value={f.email} onChange={(e) => set("email", e.target.value)} /></Field>
          <Field label="Password"><Input type="password" required minLength={6} value={f.password} onChange={(e) => set("password", e.target.value)} /></Field>
          <Field label="Phone"><Input value={f.phone} onChange={(e) => set("phone", e.target.value)} /></Field>
          <Field label="Specialization"><Input required placeholder="e.g. Cardiology" value={f.specialization} onChange={(e) => set("specialization", e.target.value)} /></Field>
          <Field label="Medical license number"><Input required value={f.licenseNumber} onChange={(e) => set("licenseNumber", e.target.value)} /></Field>
          <Field label="Degrees"><Input required placeholder="MBBS, MD..." value={f.degrees} onChange={(e) => set("degrees", e.target.value)} /></Field>
          <Field label="Years of experience"><Input type="number" min="0" value={f.yearsExperience} onChange={(e) => set("yearsExperience", e.target.value)} /></Field>
          <Field label="Hospital / clinic" full><Input value={f.hospital} onChange={(e) => set("hospital", e.target.value)} /></Field>
          <Field label="Short bio" full><Textarea value={f.bio} onChange={(e) => set("bio", e.target.value)} /></Field>
          <div className="md:col-span-2 flex items-center justify-between pt-2">
            <p className="text-xs text-muted-foreground">
              Already registered? <Link to="/doctor/login" className="text-primary underline">Sign in</Link>
            </p>
            <Button type="submit">Submit for verification</Button>
          </div>
        </form>
      </div>
    </div>
  );
}

function Field({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <div className={`space-y-2 ${full ? "md:col-span-2" : ""}`}>
      <Label>{label}</Label>
      {children}
    </div>
  );
}