import { createFileRoute } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import { Nav } from "@/components/Nav";
import { Button } from "@/components/ui/button";
import { QrCode, ShieldCheck, Stethoscope, UserPlus, ScanLine, FileHeart, Fingerprint, ScanFace, Lock, Sparkles } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background">
      <Nav />
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,_var(--color-accent)_0%,_transparent_60%)] opacity-50" />
        <div className="mx-auto max-w-6xl px-4 pb-20 pt-20 text-center">
          <div className="mx-auto inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-3 py-1 text-xs text-muted-foreground">
            <ShieldCheck className="h-3.5 w-3.5 text-primary" /> Your medical history, one scan away
          </div>
          <h1 className="mt-6 text-balance text-5xl font-semibold tracking-tight md:text-6xl">
            Carry your full medical history <span className="text-primary">in a QR code.</span>
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-pretty text-muted-foreground md:text-lg">
            Patients build a secure profile of their history, treatments, and reports. Doctors scan a QR to see it instantly — once verified by our team.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Button asChild size="lg">
              <Link to="/patient/register"><UserPlus className="mr-2 h-4 w-4" /> I'm a Patient</Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to="/doctor/register"><Stethoscope className="mr-2 h-4 w-4" /> I'm a Doctor</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-6 px-4 pb-24 md:grid-cols-3">
        {[
          { icon: FileHeart, title: "Complete history", desc: "Allergies, surgeries, accidents, medications, family history — all in one profile you control." },
          { icon: QrCode, title: "Personal QR", desc: "Each patient gets a unique QR code. Share it during an emergency or any consultation." },
          { icon: ScanLine, title: "Verified doctors only", desc: "Doctors submit credentials and are manually verified before they can scan and view." },
        ].map((f) => (
          <div key={f.title} className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
              <f.icon className="h-5 w-5" />
            </div>
            <h3 className="mt-4 text-lg font-medium">{f.title}</h3>
            <p className="mt-2 text-sm text-muted-foreground">{f.desc}</p>
          </div>
        ))}
      </section>

      <section className="border-t border-border bg-card/30">
        <div className="mx-auto max-w-6xl px-4 py-20">
          <div className="mx-auto max-w-2xl text-center">
            <div className="mx-auto inline-flex items-center gap-2 rounded-full border border-border bg-background px-3 py-1 text-xs text-muted-foreground">
              <Lock className="h-3.5 w-3.5 text-primary" /> Privacy by design
            </div>
            <h2 className="mt-4 text-balance text-3xl font-semibold tracking-tight md:text-4xl">
              Only a verified doctor's scanner can open your record.
            </h2>
            <p className="mt-4 text-muted-foreground">
              The QR code itself doesn't contain your medical data — it's just a secure reference. The actual record only loads inside a logged-in, manually verified doctor's scanner. A random phone camera scanning your QR will see nothing useful.
            </p>
          </div>

          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {[
              { icon: ShieldCheck, title: "No data in the QR", desc: "The QR only carries an opaque ID. Your history stays in the database, behind authentication." },
              { icon: Stethoscope, title: "Doctor-locked scanner", desc: "The scanner button is disabled until our team has verified the doctor's license and credentials." },
              { icon: Lock, title: "You stay in control", desc: "You can update your profile any time. Future updates will let you revoke or time-limit access." },
            ].map((f) => (
              <div key={f.title} className="rounded-2xl border border-border bg-background p-6">
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
                  <f.icon className="h-5 w-5" />
                </div>
                <h3 className="mt-4 text-lg font-medium">{f.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-20">
        <div className="rounded-3xl border border-border bg-gradient-to-br from-primary/10 via-card to-accent/30 p-10 md:p-14">
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-primary">
            <Sparkles className="h-3.5 w-3.5" /> Coming soon
          </div>
          <h2 className="mt-4 text-balance text-3xl font-semibold tracking-tight md:text-4xl">
            Biometric unlock — because a QR alone isn't always enough.
          </h2>
          <p className="mt-4 max-w-2xl text-muted-foreground">
            If a patient is unconscious or has lost their phone, the QR may not be reachable. We're adding biometric fallback so a verified doctor can still pull up the right record safely.
          </p>

          <div className="mt-10 grid gap-6 md:grid-cols-2">
            <div className="rounded-2xl border border-border bg-background/70 p-6 backdrop-blur">
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
                <Fingerprint className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-lg font-medium">Fingerprint scanner</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Doctors will be able to identify a patient by fingerprint when the QR isn't available — useful in emergency rooms and accident scenes.
              </p>
            </div>
            <div className="rounded-2xl border border-border bg-background/70 p-6 backdrop-blur">
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
                <ScanFace className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-lg font-medium">Face scanner</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                A second fallback: secure face recognition so a verified doctor can still access the patient's history if no QR or fingerprint is possible.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
