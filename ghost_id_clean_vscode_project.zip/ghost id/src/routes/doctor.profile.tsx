import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Html5Qrcode } from "html5-qrcode";
import { toast } from "sonner";
import { ScanLine, X, ShieldCheck, Clock, ShieldX } from "lucide-react";
import { Nav } from "@/components/Nav";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { doctorsStore, patientsStore, session, type Doctor, type Patient } from "@/lib/store";

export const Route = createFileRoute("/doctor/profile")({
  component: DoctorProfile,
});

function DoctorProfile() {
  const navigate = useNavigate();
  const [d, setD] = useState<Doctor | null>(null);
  const [scanning, setScanning] = useState(false);
  const [patient, setPatient] = useState<Patient | null>(null);
  const scannerRef = useRef<Html5Qrcode | null>(null);

  useEffect(() => {
    const s = session.get();
    if (s?.role !== "doctor") {
      navigate({ to: "/doctor/login" });
      return;
    }
    setD(doctorsStore.get(s.id) ?? null);
  }, [navigate]);

  useEffect(() => {
    if (!scanning) return;
    const el = document.getElementById("qr-reader");
    if (!el) return;
    const qr = new Html5Qrcode("qr-reader");
    scannerRef.current = qr;
    qr.start(
      { facingMode: "environment" },
      { fps: 10, qrbox: 250 },
      (text) => {
        try {
          const parsed = JSON.parse(text);
          if (parsed?.type === "mediqr-patient" && parsed.id) {
            const p = patientsStore.get(parsed.id);
            if (p) {
              setPatient(p);
              setScanning(false);
            } else {
              toast.error("Patient not found in database.");
            }
          } else {
            toast.error("This QR is not a MediQR code.");
          }
        } catch {
          toast.error("Invalid QR code.");
        }
      },
      () => {},
    ).catch(() => toast.error("Could not access camera."));

    return () => {
      qr.stop().then(() => qr.clear()).catch(() => {});
    };
  }, [scanning]);

  if (!d) return null;

  const statusBadge =
    d.status === "approved" ? (
      <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary"><ShieldCheck className="h-3.5 w-3.5" /> Verified</span>
    ) : d.status === "pending" ? (
      <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/10 px-3 py-1 text-xs font-medium text-amber-600"><Clock className="h-3.5 w-3.5" /> Pending verification</span>
    ) : (
      <span className="inline-flex items-center gap-1 rounded-full bg-destructive/10 px-3 py-1 text-xs font-medium text-destructive"><ShieldX className="h-3.5 w-3.5" /> Rejected</span>
    );

  return (
    <div className="min-h-screen bg-background">
      <Nav />
      <div className="mx-auto max-w-5xl px-4 py-12">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-semibold tracking-tight">Dr. {d.fullName}</h1>
            <p className="mt-1 text-sm text-muted-foreground">{d.specialization} · {d.degrees}</p>
            <div className="mt-3">{statusBadge}</div>
          </div>
          <Button
            disabled={d.status !== "approved"}
            onClick={() => setScanning(true)}
            size="lg"
          >
            <ScanLine className="mr-2 h-4 w-4" /> Scan patient QR
          </Button>
        </div>

        {d.status === "pending" && (
          <div className="mt-6 rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 text-sm text-amber-700">
            Your profile is awaiting verification by the backend support team. QR scanning unlocks once approved.
          </div>
        )}

        <div className="mt-8 grid gap-6 md:grid-cols-2">
          <Card title="Profile">
            <Row label="Email" value={d.email} />
            <Row label="Phone" value={d.phone || "—"} />
            <Row label="License #" value={d.licenseNumber} />
            <Row label="Experience" value={d.yearsExperience ? `${d.yearsExperience} years` : "—"} />
            <Row label="Hospital" value={d.hospital || "—"} />
          </Card>
          <Card title="Bio">
            <p className="text-sm text-muted-foreground whitespace-pre-wrap">{d.bio || "No bio provided."}</p>
          </Card>
        </div>
      </div>

      <Dialog open={scanning} onOpenChange={(o) => setScanning(o)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Scan patient QR</DialogTitle>
          </DialogHeader>
          <div id="qr-reader" className="w-full overflow-hidden rounded-lg" />
          <Button variant="outline" onClick={() => setScanning(false)}><X className="mr-2 h-4 w-4" /> Cancel</Button>
        </DialogContent>
      </Dialog>

      <Dialog open={!!patient} onOpenChange={(o) => !o && setPatient(null)}>
        <DialogContent className="max-h-[85vh] max-w-3xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Patient record</DialogTitle>
          </DialogHeader>
          {patient && <PatientView p={patient} />}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
      <div className="mt-3 space-y-2">{children}</div>
    </div>
  );
}
function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-4 text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-right font-medium">{value}</span>
    </div>
  );
}

function PatientView({ p }: { p: Patient }) {
  const fields: [string, string][] = [
    ["Full name", p.fullName], ["Date of birth", p.dob], ["Gender", p.gender],
    ["Blood group", p.bloodGroup], ["Phone", p.phone], ["Emergency contact", p.emergencyContact],
    ["Address", p.address],
  ];
  const history: [string, string][] = [
    ["Allergies", p.allergies], ["Chronic conditions", p.chronicConditions],
    ["Past surgeries", p.pastSurgeries], ["Past treatments", p.pastTreatments],
    ["Accidents / injuries", p.accidents], ["Current medications", p.medications],
    ["Family history", p.familyHistory], ["Reports", p.reports], ["Notes", p.notes],
  ];
  return (
    <div className="space-y-6">
      <section>
        <h4 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Personal</h4>
        <dl className="mt-3 grid gap-3 md:grid-cols-2">
          {fields.map(([k, v]) => (
            <div key={k}>
              <dt className="text-xs text-muted-foreground">{k}</dt>
              <dd className="text-sm font-medium">{v || "—"}</dd>
            </div>
          ))}
        </dl>
      </section>
      <section>
        <h4 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Medical history</h4>
        <dl className="mt-3 space-y-3">
          {history.map(([k, v]) => (
            <div key={k} className="rounded-lg border border-border bg-muted/30 p-3">
              <dt className="text-xs text-muted-foreground">{k}</dt>
              <dd className="mt-1 whitespace-pre-wrap text-sm">{v || "—"}</dd>
            </div>
          ))}
        </dl>
      </section>
    </div>
  );
}