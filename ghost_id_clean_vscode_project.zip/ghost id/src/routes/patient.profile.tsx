import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { QRCodeCanvas } from "qrcode.react";
import { toast } from "sonner";
import { Download, Save } from "lucide-react";
import { Nav } from "@/components/Nav";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { patientsStore, session, type Patient } from "@/lib/store";

export const Route = createFileRoute("/patient/profile")({
  component: PatientProfile,
});

function PatientProfile() {
  const navigate = useNavigate();
  const [p, setP] = useState<Patient | null>(null);

  useEffect(() => {
    const s = session.get();
    if (s?.role !== "patient") {
      navigate({ to: "/patient/login" });
      return;
    }
    setP(patientsStore.get(s.id) ?? null);
  }, [navigate]);

  if (!p) return null;

  const update = <K extends keyof Patient>(k: K, v: Patient[K]) =>
    setP((prev) => (prev ? { ...prev, [k]: v } : prev));

  const save = () => {
    patientsStore.upsert(p);
    toast.success("Profile saved.");
  };

  const qrValue = JSON.stringify({ type: "mediqr-patient", id: p.id });

  const downloadQR = () => {
    const canvas = document.getElementById("patient-qr") as HTMLCanvasElement | null;
    if (!canvas) return;
    const url = canvas.toDataURL("image/png");
    const a = document.createElement("a");
    a.href = url;
    a.download = `mediqr-${p.fullName || p.id}.png`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-background">
      <Nav />
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 lg:grid-cols-[1fr_320px]">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Medical Profile</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Keep this up to date. You can edit any field whenever you want.
          </p>

          <Section title="Personal details">
            <Field label="Full name"><Input value={p.fullName} onChange={(e) => update("fullName", e.target.value)} /></Field>
            <Field label="Date of birth"><Input type="date" value={p.dob} onChange={(e) => update("dob", e.target.value)} /></Field>
            <Field label="Gender"><Input value={p.gender} onChange={(e) => update("gender", e.target.value)} /></Field>
            <Field label="Blood group"><Input value={p.bloodGroup} onChange={(e) => update("bloodGroup", e.target.value)} placeholder="e.g. O+" /></Field>
            <Field label="Phone"><Input value={p.phone} onChange={(e) => update("phone", e.target.value)} /></Field>
            <Field label="Emergency contact"><Input value={p.emergencyContact} onChange={(e) => update("emergencyContact", e.target.value)} /></Field>
            <Field label="Address" full><Textarea value={p.address} onChange={(e) => update("address", e.target.value)} /></Field>
          </Section>

          <Section title="Medical history">
            <Field label="Allergies" full><Textarea value={p.allergies} onChange={(e) => update("allergies", e.target.value)} placeholder="Drugs, food, environmental..." /></Field>
            <Field label="Chronic conditions" full><Textarea value={p.chronicConditions} onChange={(e) => update("chronicConditions", e.target.value)} placeholder="Diabetes, hypertension..." /></Field>
            <Field label="Past surgeries" full><Textarea value={p.pastSurgeries} onChange={(e) => update("pastSurgeries", e.target.value)} placeholder="Procedure, year, hospital" /></Field>
            <Field label="Past treatments" full><Textarea value={p.pastTreatments} onChange={(e) => update("pastTreatments", e.target.value)} /></Field>
            <Field label="Accidents / injuries" full><Textarea value={p.accidents} onChange={(e) => update("accidents", e.target.value)} /></Field>
            <Field label="Current medications" full><Textarea value={p.medications} onChange={(e) => update("medications", e.target.value)} /></Field>
            <Field label="Family history" full><Textarea value={p.familyHistory} onChange={(e) => update("familyHistory", e.target.value)} /></Field>
            <Field label="Reports (links or summary)" full><Textarea value={p.reports} onChange={(e) => update("reports", e.target.value)} /></Field>
            <Field label="Additional notes" full><Textarea value={p.notes} onChange={(e) => update("notes", e.target.value)} /></Field>
          </Section>

          <div className="mt-8 flex justify-end">
            <Button onClick={save}><Save className="mr-2 h-4 w-4" /> Save profile</Button>
          </div>
        </div>

        <aside className="space-y-4 lg:sticky lg:top-20 h-fit">
          <div className="rounded-2xl border border-border bg-card p-6 text-center">
            <h3 className="text-sm font-medium text-muted-foreground">Your MediQR</h3>
            <p className="mt-1 text-base font-semibold">{p.fullName || "Patient"}</p>
            <div className="mx-auto mt-4 grid w-fit place-items-center rounded-xl bg-white p-4">
              <QRCodeCanvas id="patient-qr" value={qrValue} size={200} level="H" />
            </div>
            <p className="mt-3 text-xs text-muted-foreground break-all">ID: {p.id}</p>
            <Button variant="outline" size="sm" className="mt-4 w-full" onClick={downloadQR}>
              <Download className="mr-2 h-4 w-4" /> Download QR
            </Button>
          </div>
        </aside>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-8 rounded-2xl border border-border bg-card p-6">
      <h2 className="text-lg font-medium">{title}</h2>
      <div className="mt-4 grid gap-4 md:grid-cols-2">{children}</div>
    </div>
  );
}

function Field({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <div className={`space-y-2 ${full ? "md:col-span-2" : ""}`}>
      <Label>{label}</Label>
      {children}
    </div>
  );
}